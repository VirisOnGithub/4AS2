from flask import Flask, request, render_template_string, jsonify
import time

app = Flask(__name__)

# Faux système de base de données d'employés de LogiTech Express
USERS = {
    "admin": "logitech2026",
    "employe1": "motdepasse123",
    "directeur": "SuperSecr3t!"
}

# Mécanisme basique de suivi des tentatives de connexion (Rate Limiting)
FAILED_ATTEMPTS = {}
MAX_ATTEMPTS = 5
LOCKOUT_TIME = 30  # secondes

# Template HTML simple avec indicateur de force du mot de passe
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Portail LogiTech Express</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f9; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-container { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 300px; }
        h2 { color: #333; text-align: center; }
        input[type="text"], input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { background-color: #0056b3; color: white; padding: 10px; border: none; border-radius: 4px; width: 100%; cursor: pointer; font-size: 16px; }
        button:hover { background-color: #004494; }
        .message { margin-top: 15px; text-align: center; font-weight: bold; }
        .success { color: green; }
        .error { color: red; }
        .password-strength { font-size: 0.85em; margin-top: -5px; margin-bottom: 10px; display: none;}
        .weak { color: red; } .medium { color: orange; } .strong { color: green; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Intranet LogiTech</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Nom d'utilisateur" required>
            <input type="password" id="pwd" name="password" placeholder="Mot de passe" required oninput="checkStrength()">
            <div id="strength" class="password-strength">Force : <span id="strength-text">Faible</span></div>
            <button type="submit">Se connecter</button>
        </form>
        {% if message %}
            <div class="message {{ 'success' if success else 'error' }}">{{ message }}</div>
        {% endif %}
    </div>

    <script>
        function checkStrength() {
            const pwd = document.getElementById('pwd').value;
            const strengthDiv = document.getElementById('strength');
            const textSpan = document.getElementById('strength-text');
            
            if (pwd.length === 0) {
                strengthDiv.style.display = 'none';
                return;
            }
            strengthDiv.style.display = 'block';
            
            let score = 0;
            if (pwd.length > 8) score++;
            if (pwd.length >= 12) score++;
            if (/[A-Z]/.test(pwd)) score++;
            if (/[0-9]/.test(pwd)) score++;
            if (/[^A-Za-z0-9]/.test(pwd)) score++;

            if (score <= 2) {
                textSpan.textContent = 'Faible'; textSpan.className = 'weak';
            } else if (score <= 4) {
                textSpan.textContent = 'Moyen'; textSpan.className = 'medium';
            } else {
                textSpan.textContent = 'Fort'; textSpan.className = 'strong';
            }
        }
    </script>
</body>
</html>
"""

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        client_ip = request.remote_addr

        # Vérification du Rate Limiting
        current_time = time.time()
        if client_ip in FAILED_ATTEMPTS:
            attempts, last_attempt = FAILED_ATTEMPTS[client_ip]
            if attempts >= MAX_ATTEMPTS:
                if current_time - last_attempt < LOCKOUT_TIME:
                    return render_template_string(HTML_TEMPLATE, message=f"Compte bloqué (trop de tentatives). Réessayez dans {LOCKOUT_TIME}s.", success=False), 429
                else:
                    # Réinitialiser après la période de blocage
                    FAILED_ATTEMPTS[client_ip] = [0, current_time]

        # Vérification des identifiants (vulnérable au temps mais suffisant pour la démo)
        if username in USERS and USERS[username] == password:
            # Succès
            if client_ip in FAILED_ATTEMPTS:
                del FAILED_ATTEMPTS[client_ip]
            return render_template_string(HTML_TEMPLATE, message=f"Bienvenue, {username} ! Accès autorisé.", success=True)
        else:
            # Échec
            if client_ip in FAILED_ATTEMPTS:
                FAILED_ATTEMPTS[client_ip][0] += 1
                FAILED_ATTEMPTS[client_ip][1] = current_time
            else:
                FAILED_ATTEMPTS[client_ip] = [1, current_time]
            return render_template_string(HTML_TEMPLATE, message="Identifiants incorrects.", success=False), 401

    return render_template_string(HTML_TEMPLATE)

if __name__ == '__main__':
    print("Démarrage de l'Intranet LogiTech Express sur http://127.0.0.1:5000")
    app.run(debug=True, port=5000)
