# Projet de Sensibilisation à la Cybersécurité : LogiTech Express

Ce projet permet de faire une présentation live et pragmatique pour sensibiliser aux risques cyber, en particulier concernant les mots de passe.

## Contenu

1. **Rapport (`rapport/rapport.typ`)** : Un fichier Typst contenant un rapport court et chiffré sur l'état de la cybersécurité, le scénario, et le plan d'action de remédiation.
2. **L'application web (`app/app.py`)** : Le portail interne de l'entreprise "LogiTech Express". Cette page d'authentification inclut un système d'analyse de forme de mots de passe + une protection Rate-Limiting basique. (Développé en Python / Flask).
3. **Le Script d'Attaque (`attaque/exploit.py`)** : Un script de démonstration par dictionnaire (Brute Force).

## Prérequis

- Python 3
- Flask (`pip install Flask`)
- Requests (`pip install requests`)
- Typst (pour compiler le rapport PDF)

## Déroulement du scénario d'attaque

### Étape 1 : Démarrer la cible
Ouvrez votre terminal, placez-vous dans le dossier `app` et lancez l'application :
```bash
python3 app.py
```
Le serveur écoutera sur `http://127.0.0.1:5000`.

### Étape 2 : Lancer l'attaque
Dans un second terminal, placez-vous dans le dossier `attaque` et lancez l'exploit Python :
```bash
python3 exploit.py
```
Le script va tester les mots de passe du dictionnaire `passwords.txt`. Si l'attaque est bloquée au bout de 5 essais, c'est que la sécurité Rate-Limiting intégrée fonctionne ! Pour voir un vrai succès, désactivez la condition limitante dans le code de `app.py`.

### Étape 3 : Explication
Utilisez le rapport pour appuyer vos dires, en démontrant à l'auditoire que la machine peut tester des milliers de combinaisons très vite, et que la complexité (+ MFA) est la seule vraie défense.