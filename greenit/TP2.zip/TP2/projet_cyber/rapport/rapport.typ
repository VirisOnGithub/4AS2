// Rapport Cybersécurité
#set page(paper: "a4", margin: 2cm)
#set text(font: "Linux Libertine", size: 12pt)

#align(center)[
  #text(size: 24pt, weight: "bold")[Sensibilisation à la Cybersécurité] \
  #v(1em)
  #text(size: 16pt)[Cas pragmatique : Entreprise LogiTech Express] \
  #v(2em)
  #text(size: 12pt)[Rapport stratégique et technique]
]

#v(3em)

== 1. Contexte : Les enjeux cyber face à LogiTech Express
LogiTech Express est une PME de logistique en pleine croissance (250 employés). Avec la digitalisation de sa chaîne logistique, l'entreprise devient une cible privilégiée.

*Chiffres clés de la menace :*
- *En France (2025)* : Plus de 40% des PME ont été victimes d'une cyberattaque.
- *Coût moyen* : Le coût moyen d'une violation de données pour les entreprises frôle les 4 millions d'euros.
- *Vecteur principal* : 80% des failles de sécurité impliquent l'utilisation de mots de passe compromis ou faibles, souvent via le phishing.
- *Ransomware* : 50% des attaques critiques ciblées sur des PME impliquent un ransomware, bloquant l'activité pendant plusieurs jours.

*(Sources : Rapports de l'ANSSI (Agence Nationale de la Sécurité des Systèmes d'Information) et de la CNIL).*

== 2. Scénario d'attaque : Démonstration d'une attaque par Brute-Force
Lors d'une présentation de sensibilisation, il est crucial de montrer à quel point un mot de passe faible est dangereux.
L'attaque simulée consistera à exploiter une simple page de connexion interne (sans protection anti-fuzzing) à l'aide d'un script automatisé qui teste des milliers de mots de passe à la seconde.

*Méthodologie (reproductible en live) :*
1. *Déploiement de l'app* : Lancer le portail vulnérable de LogiTech Express.
2. *Lancement de l'attaque* : Exécuter le script Python d'attaque de dictionnaire.
3. *Constat* : En moins de 3 secondes, le mot de passe "logitech2026" est compromis.

== 3. Solutions concrètes et Plan d'action
Pour protéger LogiTech Express, voici les mesures immédiates :

- *Authentification forte* : Mise en place obligatoire de l'authentification multifacteur (MFA).
- *Filtrage et Rate-Limiting* : Bloquer les tentatives de connexion répétées (ex: 5 essais maximum par minute).
- *Sensibilisation continue* : Campagnes trimestrielles de simulation de phishing.
- *Gestionnaire de mots de passe* : Déploiement d'un outil d'entreprise pour générer des mots de passe robustes (min 14 caractères alphanumériques + symboles).

== 4. Produit délivrable : "Cyber-Check Login Portal"
Nous vous avons développé un outil applicatif démontrant une interface de connexion sécurisée intégrant :
- Un système de vérification de robustesse du mot de passe en temps réel.
- Une protection contre les attaques par force brute (simulation de blocage).
(Voir le code source joint en Python / Flask).
