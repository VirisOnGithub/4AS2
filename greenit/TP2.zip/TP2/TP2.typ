#import "@local/polytech:1.0.0": *

#show: conf(doctitle: "TP2", subject: "Green IT")[
  
]